'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/lib/cart-context';

const menuItems = [
  { label: 'Каталог', slug: '/catalog' },
  { label: 'Контакты', slug: '/contacts' },
  { label: 'Доставка и оплата', slug: '/delivery' },
  { label: 'Гарантия', slug: '/guarantee' },
  { label: 'Индивидуальный пошив', slug: '/custom' },
];

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { cartCount, setIsOpen: setCartOpen } = useCart();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/catalog?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <Link href="/" className="text-xl font-bold tracking-wider text-black">
            LINUCHI
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {menuItems.map((item) => (
              <Link
                key={item.slug}
                href={item.slug}
                className="text-sm text-black hover:text-gray-600 transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Right Section: Phone, Search, Cart */}
          <div className="hidden lg:flex items-center gap-4">
            <span className="text-sm text-black">ПН-ПТ 8:00-20:00</span>
            <a href="tel:+375293870980" className="text-sm font-medium text-black hover:text-gray-600">
              +375 29 387-09-80
            </a>
            <button onClick={() => setCartOpen(true)} className="relative text-black p-1">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-black text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                  {cartCount > 9 ? '9+' : cartCount}
                </span>
              )}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="lg:hidden text-black p-1">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 py-4 space-y-1">
            {menuItems.map((item) => (
              <Link
                key={item.slug}
                href={item.slug}
                className="block px-2 py-2 text-sm text-black hover:bg-gray-50 rounded"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-2 border-t border-gray-200">
              <span className="block px-2 py-2 text-sm text-gray-500">ПН-ПТ 8:00-20:00</span>
              <a href="tel:+375293870980" className="block px-2 py-2 text-sm font-medium text-black">
                +375 29 387-09-80
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
