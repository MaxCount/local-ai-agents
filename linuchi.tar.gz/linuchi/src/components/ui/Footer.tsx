import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo */}
          <div>
            <Link href="/" className="text-2xl font-bold tracking-wider">
              LINUCHI
            </Link>
          </div>

          {/* Каталог */}
          <div>
            <h3 className="font-semibold mb-4">Каталог</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/catalog?category=chexly" className="hover:text-white">Чехлы</Link></li>
              <li><Link href="/catalog?category=portpledy" className="hover:text-white">Портпледы</Link></li>
              <li><Link href="/catalog?category=sumki" className="hover:text-white">Сумки</Link></li>
              <li><Link href="/catalog" className="hover:text-white">Рюкзаки</Link></li>
              <li><Link href="/custom" className="hover:text-white">На заказ</Link></li>
            </ul>
          </div>

          {/* Контакты */}
          <div>
            <h3 className="font-semibold mb-4">Контакты</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>+375 29 387-09-80</li>
              <li>г. Борисов, ул. Дзержинского 90 офис 3</li>
              <li>Пн-Пт 8:00-16:00</li>
            </ul>
          </div>

          {/* Info */}
          <div>
            <h3 className="font-semibold mb-4">Информация</h3>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/contacts" className="hover:text-white">Контакты</Link></li>
              <li><Link href="/delivery" className="hover:text-white">Доставка и оплата</Link></li>
              <li><Link href="/guarantee" className="hover:text-white">Гарантия</Link></li>
              <li><Link href="/custom" className="hover:text-white">Индивидуальный пошив</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
          <span>УНП: 94828904801г. Борисов, ул. Дзержинского 90 офис 3</span>
          <span>Сайт разработан ✓</span>
        </div>
      </div>
    </footer>
  );
}
