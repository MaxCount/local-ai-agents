'use client';

import { useCart } from '@/lib/cart-context';
import { useState } from 'react';

interface Product {
  id: string;
  title: string;
  price: number;
  salePrice?: number;
  images?: { url: string }[];
}

export default function AddToCartButton({ product }: { product: Product }) {
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const imageUrl = product.images?.[0]?.url || '/placeholder.jpg';

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      title: product.title,
      price: product.salePrice || product.price,
      quantity,
      image: imageUrl,
    });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-4">
        <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="border px-3 py-1">-</button>
        <span>{quantity}</span>
        <button onClick={() => setQuantity(q => q + 1)} className="border px-3 py-1">+</button>
      </div>
      <button onClick={handleAddToCart} className="bg-black text-white px-6 py-3 w-full">
        Добавить в корзину
      </button>
    </div>
  );
}
