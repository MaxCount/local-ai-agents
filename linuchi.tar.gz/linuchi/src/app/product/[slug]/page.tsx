import { getProductBySlug, getProducts } from '@/lib/queries';
import ProductCard from '@/components/ui/ProductCard';
import { notFound } from 'next/navigation';
import AddToCartButton from './AddToCartButton';
import ImageGallery from './ImageGallery';

interface PageProps {
  params: Promise<{ slug: string }>;
}

async function getProduct(slug: string) {
  const product = await getProductBySlug(slug);
  return product;
}

async function getRelatedProducts(currentProductId: string) {
  const products = await getProducts({ limit: 3 });
  return products.filter(p => p.id !== currentProductId).slice(0, 3);
}

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params;
  const product = await getProduct(slug);

  if (!product) {
    notFound();
  }

  const relatedProducts = await getRelatedProducts(product.id);
  const images = product.images?.length ? product.images : [{ url: '/placeholder.jpg' }];
  const displayPrice = product.salePrice || product.price;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <div className="mb-4 text-sm text-gray-500">
        <span>Назад</span>
        <span className="mx-2">/</span>
        <span>{product.category?.name || 'Каталог'}</span>
        <span className="mx-2">/</span>
        <span className="text-black">{product.title}</span>
      </div>

      {/* Product */}
      <div className="mb-2">
        <span className="text-sm text-gray-500 uppercase">{product.category?.name}</span>
      </div>
      <h1 className="text-2xl font-bold mb-4">{product.title}</h1>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* Images */}
        <ImageGallery images={images} productTitle={product.title} />

        {/* Info */}
        <div>
          <div className="flex items-baseline gap-3 mb-4">
            <span className="text-2xl font-bold">{displayPrice.toFixed(2)} руб</span>
            {product.salePrice && (
              <span className="text-lg text-gray-400 line-through">{product.price.toFixed(2)} руб</span>
            )}
          </div>

          {product.description && (
            <p className="text-gray-700 mb-6">{product.description}</p>
          )}

          {/* Features */}
          {product.features && product.features.length > 0 && (
            <ul className="space-y-2 mb-6">
              {product.features.map((feature, index) => (
                <li key={index} className="text-sm text-gray-600">• {feature}</li>
              ))}
            </ul>
          )}

          <AddToCartButton product={product} />
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="border-t pt-8">
          <h2 className="text-xl font-bold mb-4">Похожие товары</h2>
          <div className="grid grid-cols-3 gap-4">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
