import { getProducts } from '@/lib/queries';
import ProductCard from '@/components/ui/ProductCard';

const categories = [
  { name: 'Чехлы', slug: 'chexly' },
  { name: 'Чехлы для', slug: 'chexly-dlya' },
  { name: 'Портпледы', slug: 'portpledy' },
  { name: 'Сумки', slug: 'sumki' },
];

interface PageProps {
  searchParams: Promise<{ category?: string; search?: string }>;
}

export default async function CatalogPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const products = await getProducts({ category: params.category, search: params.search });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm mb-6">
        {categories.map((cat) => (
          <span key={cat.slug} className="text-gray-700 hover:text-black cursor-pointer">
            {cat.name}
          </span>
        ))}
      </div>

      <h1 className="text-2xl font-bold mb-6">Каталог</h1>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}
