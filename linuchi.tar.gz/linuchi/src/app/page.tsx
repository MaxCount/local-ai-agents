import Link from "next/link";
import { getProducts } from "@/lib/queries";
import ProductCard from "@/components/ui/ProductCard";

const categories = [
  {
    name: "Чехлы",
    slug: "chexly",
    subcategories: ["Свадебные", "Из оксфорда", "Антимолевые", "Чехлы для"],
  },
  {
    name: "Чехлы для",
    slug: "chexly-dlya",
    subcategories: ["Ковриков йоги", "Балетных пачек", "Укулели"],
  },
  {
    name: "Портпледы",
    slug: "portpledy",
    subcategories: ["Для купальника", "Дорожные", "Школьные"],
  },
  {
    name: "Сумки",
    slug: "sumki",
    subcategories: ["Для ноутбуков", "Кожаные", "С защитой от дождя"],
  },
];

export default async function HomePage() {
  const products = await getProducts({ limit: 6 });

  return (
    <div>
      {/* Categories Nav */}
      <div className="bg-gray-100 py-3">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
            {categories.map((cat) => (
              <div key={cat.slug} className="relative group">
                <Link href={`/catalog?category=${cat.slug}`} className="text-gray-700 hover:text-black">
                  {cat.name}
                </Link>
                {cat.subcategories && cat.subcategories.length > 0 && (
                  <div className="absolute left-0 top-full mt-1 bg-white border shadow-lg rounded p-3 min-w-40 hidden group-hover:block z-10">
                    {cat.subcategories.map((sub) => (
                      <Link
                        key={sub}
                        href={`/catalog?category=${cat.slug}`}
                        className="block py-1 text-sm text-gray-700 hover:text-black"
                      >
                        {sub}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
