import Image from "next/image";

export default function ContactsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-6">
        <span className="text-sm text-gray-500">Назад</span>
      </div>

      <h1 className="text-2xl font-bold mb-6">Контакты</h1>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Info */}
        <div className="space-y-6">
          <div>
            <h3 className="text-sm text-gray-500 mb-1">телефон</h3>
            <p className="text-xl font-bold">+375 (29) 387-09-80</p>
          </div>

          <div>
            <h3 className="text-sm text-gray-500 mb-1">адрес</h3>
            <p className="font-medium">г. Борисов, ул. Дзержинского 90 офис 3</p>
          </div>

          <div>
            <h3 className="text-sm text-gray-500 mb-1">график работы</h3>
            <p className="font-medium">ПН-ПТ 8:00-16:00</p>
          </div>

          <div className="bg-gray-100 p-4 rounded">
            <p className="text-sm text-gray-500">Карта расположения офиса</p>
          </div>
        </div>

        {/* Map placeholder */}
        <div className="bg-gray-100 rounded aspect-video flex items-center justify-center">
          <span className="text-gray-400">Карта</span>
        </div>
      </div>
    </div>
  );
}
